import './faq.js'
import './swiper-reviews.js'
import './burger.js'